/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingapplication;

/**
 *
 * @author Ellis
 */
public class LinkList<T> {
    Node<T> head,tail;
    
    void add(T input){
        Node<T> x = new Node<T>();
        x.setData(input);
        
        this.tail=this.head;
        this.head=x;
    }
    
    T pollLast(){
        Node<T> x=tail;
        T y=null;
        if(x.equals(null)){
            y=head.getData();
        }
        while(x!=null){
            if(x.getNext().getData().equals(null)){
                y = x.getData();
                x.setData(null);
            }
            else{
                x=x.getNext();
            }
        }
        return y;
    }
    
    T pollFirst(){
        T x=head.getData();
        head=tail;
        tail=tail.getNext();
        return x;
    }
    
    T peekFirst(){
        T x=head.getData();
        return x;
    }
    
    T peekLast(){
        Node<T> x=tail;
        T y=null;
        if(x.equals(null)){
            y=head.getData();
        }
        while(x!=null){
            if(x.getNext().getData().equals(null)){
                y = x.getData();
            }
            else{
                x=x.getNext();
            }
        }
        return y;
    }
}
