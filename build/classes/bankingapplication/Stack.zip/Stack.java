/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingapplication;

import java.util.LinkedList;
import static javafx.scene.input.KeyCode.T;

/**
 *
 * @author Ellis
 */
public class Stack<T> {
    LinkList<T> x;
    
    public Stack(){
        this.x=new LinkList<T>();
    }
    
    void push(T i){
        x.add(i);
    }
    
    T pop(){
        return x.pollFirst();
    }
    
    T peek(){
        return x.peekFirst();
    }
}
